function JobAdCtrl($scope) {
	$scope.job = job;
	$scope.company_profile = company_profile;
}